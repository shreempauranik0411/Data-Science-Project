#!/usr/bin/env python
# coding: utf-8

# In[1]:


get_ipython().system('pip install folium')
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
from itertools import combinations
from collections import Counter
import folium
from scipy.stats import chi2_contingency
import matplotlib.pyplot as plt


# In[19]:


df=pd.read_csv("Dataset .csv")
df.head()


# In[20]:


df.shape


# In[21]:


df.isnull()


# In[22]:


df.isnull().sum()


# In[23]:


print(df.dtypes)


# In[24]:


df.info()


# In[25]:


#level1 Task1(Top Cuisine)
cuisine_counts = df["Cuisines"].value_counts()

sorted_cuisine_counts = cuisine_counts.sort_values(ascending=False)

top_three_cuisines = sorted_cuisine_counts.head(3)

print("The three most cuisines are:")
print(top_three_cuisines)


# In[26]:


#level1 Task1(Top Cuisine)
total_restaurants = len("Dataset.csv")

percentage_top_cuisine1 = (top_three_cuisines[0] / total_restaurants)*100
percentage_top_cuisine2 = (top_three_cuisines[1] / total_restaurants)*100
percentage_top_cuisine3 = (top_three_cuisines[2] / total_restaurants)*100

print("Percentage of restaurants serving the top three cuisines:")
print(f"1 {top_three_cuisines.index[0]}): {percentage_top_cuisine1:.2f}%")
print(f"2 {top_three_cuisines.index[1]}): {percentage_top_cuisine1:.2f}%")
print(f"3 {top_three_cuisines.index[2]}): {percentage_top_cuisine1:.2f}%")


# In[27]:


#level1 Task2(City Analysis)
restaurant_counts_by_city = df['City'].value_counts()

city_with_highest_restaurants = restaurant_counts_by_city.idxmax()
highest_restaurant_count = restaurant_counts_by_city.max()

print(f"The cith with the highest number of restaurant is {city_with_highest_restaurants} with {highest_restaurant_count} restaurant")


# In[28]:


#level1 Task2(City Analysis)
average_rating_by_city = df.groupby('City')['Aggregate rating'].mean()

print("Average rating for restaurants in each city:")
print(average_rating_by_city)

average_rating_by_city = df.groupby('City')['Aggregate rating'].mean()


city_with_highest_average_rating = average_rating_by_city.idxmax()
highest_average_rating = average_rating_by_city.max()

print(f"The city with the highest average rating is {city_with_highest_average_rating} with an average rating of {highest_average_rating:.2f}.")


# In[29]:


#Level1 Task3(Price Range Distribution)
price_range_counts = df['Price range'].value_counts()

#Plotting the histogram or barchart
plt.figure(figsize=(8,6))
price_range_counts.plot(kind = 'bar', color = 'skyblue')
plt.title('Distribution of Price Ranges Among Restaurants')
plt.xlabel('Price Range')
plt.ylabel('Number of Restaurants')
plt.xticks(rotation=0)
plt.grid(axis='y', linestyle='--', alpha = 0.7)
plt.tight_layout()
plt.show()


# In[9]:


#Level1 Task4(Online Delivery)
df=pd.read_csv("Dataset .csv")
total_restaurants = len(df)

restaurants_with_delivery = df['Has Online delivery'].sum()

percentage_with_delivery = (restaurants_with_delivery / total_restaurants) * 100

print(f"Percentage of restaurants offering online delivery: {percentage_with_delivery:.2f}%")


# In[99]:


#Level1 Task4(Online Delivery)
total_restaurants = len("Dataset.csv")

cleaned_data = df.dropna(subset=['Aggregate rating', 'Has Online delivery'])  
cleaned_data['offers_delivery'] = cleaned_data['Has Online delivery'].apply(lambda x: 'Yes' if x == 'Online' else 'No')


avg_ratings_with_delivery = cleaned_data[cleaned_data['Has Online delivery'] == 'Yes']['Aggregate rating'].mean()
avg_ratings_without_delivery = cleaned_data[cleaned_data['Has Online delivery'] == 'No']['Aggregate rating'].mean()


print(f"Average rating for restaurants with online delivery: {avg_ratings_with_delivery:.2f}")
print(f"Average rating for restaurants without online delivery: {avg_ratings_without_delivery:.2f}")


# In[70]:


#Level2 Task1(Restaurant Ratings)
total_restaurants = len("Dataset.csv")

cleaned_data = df.dropna(subset=['Aggregate rating'])  


plt.figure(figsize=(10, 6))
plt.hist(cleaned_data['Aggregate rating'], bins=10, color='skyblue', edgecolor='black')
plt.title('Distribution of Aggregate Ratings')
plt.xlabel('Aggregate Rating')
plt.ylabel('Frequency')
plt.grid(True)
plt.show()


rating_counts = cleaned_data['Aggregate rating'].value_counts()
most_common_rating = rating_counts.idxmax()
most_common_rating_count = rating_counts.max()

print(f"The most common rating range is {most_common_rating} with a count of {most_common_rating_count}.")


# In[72]:


#Level2 Task1(Restaurant Ratings)
cleaned_data = df.dropna(subset=['Votes'])  

average_votes = cleaned_data['Votes'].mean()

print(f"The average number of votes received by restaurants is: {average_votes:.2f}")


# In[100]:


#Level2 Task2(Cuisine Combination)
df['Cuisines'] = df['Cuisines'].str.lower().str.strip()

df['Cuisine_combinations'] = df['Cuisines'].str.split(',').apply(lambda x: list(combinations(x, 2)))


cuisine_combinations = [item for sublist in df['Cuisine_combinations'] for item in sublist]
most_common_combinations = Counter(cuisine_combinations).most_common(10)  # Change 10 to desired number of top combinations


print("Top 10 most common cuisine combinations:")
for combination, count in most_common_combinations:
    print(f"{', '.join(combination)}: {count} occurrences")


# In[79]:


#Level2 Task2(Cuisine Combination)
df.dropna(subset=['Cuisines', 'Aggregate rating'], inplace=True)

df['Rating'] = pd.to_numeric(df['Aggregate rating'], errors='coerce')

df['Cuisine_combinations'] = df['Cuisines'].str.split(',').apply(lambda x: tuple(sorted(x)))

average_ratings = df.groupby('Cuisine_combinations')['Aggregate rating'].mean().reset_index()

print("Average ratings for cuisine combinations:")
print(average_ratings)


# In[119]:


#Level2 Task3(Geographic Analysis)
df.dropna(subset=['Latitude', 'Longitude'], inplace=True)

map_restaurants = folium.Map(location=[df['Latitude'].mean(), df['Longitude'].mean()], zoom_start=10)

for index, row in df.iterrows():
    folium.Marker([row['Latitude'], row['Longitude']], popup=row['Restaurant Name']).add_to(map_restaurants)

map_restaurants.save("restaurant_map.html")


# In[8]:


#Level2 Task3(Geographic Analysis)
df=pd.read_csv("Dataset .csv")
df.dropna(subset=['Latitude', 'Longitude'], inplace=True)

X = df[['Latitude', 'Longitude']].values

num_clusters = 5

kmeans = KMeans(n_clusters=num_clusters, random_state=0).fit(X)

df['Cluster'] = kmeans.labels_

map_clusters = folium.Map(location=[df['Latitude'].mean(), df['Longitude'].mean()], zoom_start=10)

cluster_colors = ['red', 'blue', 'green', 'orange', 'purple']  

for index, row in df.iterrows():
    folium.Marker([row['Latitude'], row['Longitude']], 
                  popup=f"Cluster: {row['Cluster']}",
                  icon=folium.Icon(color=cluster_colors[row['Cluster']])).add_to(map_clusters)

map_clusters.save("restaurant_clusters.html")


# In[95]:


#Level2 Task4(Restaurant Chains)
df['Restaurant Name'] = df['Restaurant Name'].str.lower().str.strip()

restaurant_counts = df['Restaurant Name'].value_counts()

restaurant_chains = restaurant_counts[restaurant_counts > 1]

print("Identified restaurant chains:")
print(restaurant_chains)


# In[103]:


#Level2 Task4(Restaurant Chains)
df['Restaurant Name'] = df['Restaurant Name'].str.lower().str.strip()

restaurant_counts = df['Restaurant Name'].value_counts()

restaurant_chains = restaurant_counts[restaurant_counts > 1].index

chain_ratings = {}
chain_popularity = {}
for chain in restaurant_chains:
    chain_data = df[df['Restaurant Name'] == chain]
    avg_rating = chain_data['Aggregate rating'].mean()
    total_popularity = chain_data['Rating text'].sum()
    chain_ratings[chain] = avg_rating
    chain_popularity[chain] = total_popularity

ratings_df = pd.DataFrame.from_dict(chain_ratings, orient='index', columns=['Average Rating'])
popularity_df = pd.DataFrame.from_dict(chain_popularity, orient='index', columns=['Total Popularity'])

ratings_df = ratings_df.sort_values(by='Average Rating', ascending=False)
popularity_df = popularity_df.sort_values(by='Total Popularity', ascending=False)

print("Average Ratings of Restaurant Chains:")
print(ratings_df.head(10))  
print("\nTotal Popularity of Restaurant Chains:")
print(popularity_df.head(10)) 


# In[109]:


#Level3 Task2(Votes Analysis)
highest_votes_restaurant = df.loc[df['Votes'].idxmax()]
lowest_votes_restaurant = df.loc[df['Votes'].idxmin()]


print("Restaurant with the highest number of votes:")
print(highest_votes_restaurant)

print("\nRestaurant with the lowest number of votes:")
print(lowest_votes_restaurant)


# In[110]:


#Level3 Task2(Votes Analysis)
correlation_coefficient = df['Votes'].corr(df['Aggregate rating'])

print("Correlation Coefficient between Number of Votes and Rating:", correlation_coefficient)


# In[114]:


#Level3 Task3(Price Range vs. Online Delivery and Table Booking)
contingency_table = pd.crosstab(df['Price range'], [df['Has Online delivery'], df['Has Table booking']])

chi2, p, dof, expected = chi2_contingency(contingency_table)

print("Chi-square Statistic:", chi2)
print("P-value:", p)
print("Degrees of Freedom:", dof)
print("Expected Frequencies Table:")
print(expected)


# In[ ]:





# In[ ]:




